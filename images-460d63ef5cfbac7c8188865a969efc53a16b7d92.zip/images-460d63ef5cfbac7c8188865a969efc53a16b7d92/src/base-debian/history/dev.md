# [base-debian](https://github.com/devcontainers/images/tree/main/src/base-debian)

**Image version:** dev

**Source release/branch:** [main](https://github.com/devcontainers/images/tree/main/src/base-debian)

**Image variations:**
- [trixie](#variant-trixie)
- [bookworm](#variant-bookworm)
- [bullseye](#variant-bullseye)

## Variant: trixie

**Digest:** sha256:8cdf7ba5665149ab029634959f5b5bd52d267ef14c66e267c8c1291817f4f46d

**Tags:**
```
mcr.microsoft.com/devcontainers/base:dev-trixie
mcr.microsoft.com/devcontainers/base:dev-debian13
mcr.microsoft.com/devcontainers/base:dev-debian
mcr.microsoft.com/devcontainers/base:dev
```
> *To keep up to date, we recommend using partial version numbers. Use the major version number to get all non-breaking changes (e.g. `0-`) or major and minor to only get fixes (e.g. `0.200-`).*

**Linux distribution:** Debian GNU/Linux 13 (trixie)

**Architectures:** linux/amd64, linux/arm64

**Available (non-root) user:** vscode

### Contents
**Tools installed using git**

| Tool | Commit | Path |
|------|--------|------|
| [Oh My Zsh!](https://github.com/ohmyzsh/ohmyzsh) | 67cd8c4673512d08238461f7ce00715da01665d4 | /home/vscode/.oh-my-zsh |

**Other tools and utilities**

| Tool | Version | Path |
|------|---------|------|
| [git](https://github.com/git/git) | 2.52.0 | 

**Additional linux tools and packages**

| Tool / library | Version |
|----------------|---------|
| apt-transport-https | 3.0.3 |
| apt-utils | 3.0.3 |
| ca-certificates | 20250419 |
| curl | 8.14.1-2+deb13u2 |
| dialog | 1.3-20250116-1 |
| git | 1:2.47.3-0+deb13u1 |
| gnupg2 | 2.4.7-21+deb13u1 |
| htop | 3.4.1-5 |
| iproute2 | 6.15.0-1 |
| jq | 1.7.1-6+deb13u1 |
| less | 668-1 |
| libc6 | 2.41-12+deb13u1 |
| libgssapi-krb5-2 | 1.21.3-5 |
| libicu76 | 76.1-4 |
| libkrb5-3 | 1.21.3-5 |
| libstdc++6 | 14.2.0-19 |
| locales | 2.41-12+deb13u1 |
| lsb-release | 12.1-1 |
| lsof | 4.99.4+dfsg-2 |
| man-db | 2.13.1-1 |
| manpages | 6.9.1-1 |
| manpages-dev | 6.9.1-1 |
| nano | 8.4-1 |
| ncdu | 1.22-1 |
| net-tools | 2.10-1.3 |
| openssh-client | 1:10.0p1-7 |
| procps | 2:4.0.4-9 |
| psmisc | 23.7-2 |
| rsync | 3.4.1+ds1-5+deb13u1 |
| strace | 6.13+ds-1 |
| sudo | 1.9.16p2-3 |
| unzip | 6.0-29 |
| vim-tiny | 2:9.1.1230-2 |
| wget | 1.25.0-2 |
| zip | 3.0-15 |
| zlib1g | 1:1.3.dfsg+really1.3.1-1+b1 |
| zsh | 5.9-8+b18 |

## Variant: bookworm

**Digest:** sha256:c18126f27096329c038bbb10f23ad4a109519dce4fcdd106626cb1558e34d4b6

**Tags:**
```
mcr.microsoft.com/devcontainers/base:dev-bookworm
mcr.microsoft.com/devcontainers/base:dev-debian12
```
> *To keep up to date, we recommend using partial version numbers. Use the major version number to get all non-breaking changes (e.g. `0-`) or major and minor to only get fixes (e.g. `0.200-`).*

**Linux distribution:** Debian GNU/Linux 12 (bookworm)

**Architectures:** linux/amd64, linux/arm64

**Available (non-root) user:** vscode

### Contents
**Tools installed using git**

| Tool | Commit | Path |
|------|--------|------|
| [Oh My Zsh!](https://github.com/ohmyzsh/ohmyzsh) | 67cd8c4673512d08238461f7ce00715da01665d4 | /home/vscode/.oh-my-zsh |

**Other tools and utilities**

| Tool | Version | Path |
|------|---------|------|
| [git](https://github.com/git/git) | 2.52.0 | 

**Additional linux tools and packages**

| Tool / library | Version |
|----------------|---------|
| apt-transport-https | 2.6.1 |
| apt-utils | 2.6.1 |
| ca-certificates | 20230311+deb12u1 |
| curl | 7.88.1-10+deb12u14 |
| dialog | 1.3-20230209-1 |
| git | 1:2.39.5-0+deb12u3 |
| gnupg2 | 2.2.40-1.1+deb12u2 |
| htop | 3.2.2-2 |
| iproute2 | 6.1.0-3 |
| jq | 1.6-2.1+deb12u1 |
| less | 590-2.1~deb12u2 |
| libc6 | 2.36-9+deb12u13 |
| libgssapi-krb5-2 | 1.20.1-2+deb12u4 |
| libicu72 | 72.1-3+deb12u1 |
| libkrb5-3 | 1.20.1-2+deb12u4 |
| liblttng-ust1 | 2.13.5-1 |
| libstdc++6 | 12.2.0-14+deb12u1 |
| locales | 2.36-9+deb12u13 |
| lsb-release | 12.0-1 |
| lsof | 4.95.0-1 |
| man-db | 2.11.2-2 |
| manpages | 6.03-2 |
| manpages-dev | 6.03-2 |
| nano | 7.2-1+deb12u1 |
| ncdu | 1.18-0.2 |
| net-tools | 2.10-0.1+deb12u2 |
| openssh-client | 1:9.2p1-2+deb12u7 |
| procps | 2:4.0.2-3 |
| psmisc | 23.6-1 |
| rsync | 3.2.7-1+deb12u4 |
| strace | 6.1-0.1 |
| sudo | 1.9.13p3-1+deb12u3 |
| unzip | 6.0-28 |
| vim-tiny | 2:9.0.1378-2+deb12u2 |
| wget | 1.21.3-1+deb12u1 |
| zip | 3.0-13 |
| zlib1g | 1:1.2.13.dfsg-1 |
| zsh | 5.9-4+b8 |

## Variant: bullseye

**Digest:** sha256:1acbed8676a0b64e0523d3479e30f6e1feb39007db5f31f238e385a84dc4a42c

**Tags:**
```
mcr.microsoft.com/devcontainers/base:dev-bullseye
mcr.microsoft.com/devcontainers/base:dev-debian11
```
> *To keep up to date, we recommend using partial version numbers. Use the major version number to get all non-breaking changes (e.g. `0-`) or major and minor to only get fixes (e.g. `0.200-`).*

**Linux distribution:** Debian GNU/Linux 11 (bullseye)

**Architectures:** linux/amd64, linux/arm64

**Available (non-root) user:** vscode

### Contents
**Tools installed using git**

| Tool | Commit | Path |
|------|--------|------|
| [Oh My Zsh!](https://github.com/ohmyzsh/ohmyzsh) | 67cd8c4673512d08238461f7ce00715da01665d4 | /home/vscode/.oh-my-zsh |

**Other tools and utilities**

| Tool | Version | Path |
|------|---------|------|
| [git](https://github.com/git/git) | 2.52.0 | 

**Additional linux tools and packages**

| Tool / library | Version |
|----------------|---------|
| apt-transport-https | 2.2.4 |
| apt-utils | 2.2.4 |
| ca-certificates | 20210119 |
| curl | 7.74.0-1.3+deb11u16 |
| dialog | 1.3-20201126-1 |
| git | 1:2.30.2-1+deb11u5 |
| gnupg2 | 2.2.27-2+deb11u3 |
| htop | 3.0.5-7 |
| iproute2 | 5.10.0-4 |
| jq | 1.6-2.1+deb11u1 |
| less | 551-2+deb11u2 |
| libc6 | 2.31-13+deb11u13 |
| libgssapi-krb5-2 | 1.18.3-6+deb11u7 |
| libicu67 | 67.1-7+deb11u1 |
| libkrb5-3 | 1.18.3-6+deb11u7 |
| liblttng-ust0 | 2.12.1-1 |
| libssl1.1 | 1.1.1w-0+deb11u4 |
| libstdc++6 | 10.2.1-6 |
| locales | 2.31-13+deb11u13 |
| lsb-release | 11.1.0 |
| lsof | 4.93.2+dfsg-1.1 |
| man-db | 2.9.4-2 |
| manpages | 5.10-1 |
| manpages-dev | 5.10-1 |
| nano | 5.4-2+deb11u3 |
| ncdu | 1.15.1-1 |
| net-tools | 1.60+git20181103.0eebece-1+deb11u2 |
| openssh-client | 1:8.4p1-5+deb11u5 |
| procps | 2:3.3.17-5 |
| psmisc | 23.4-2 |
| rsync | 3.2.3-4+deb11u3 |
| strace | 5.10-1 |
| sudo | 1.9.5p2-3+deb11u2 |
| unzip | 6.0-26+deb11u1 |
| vim-tiny | 2:8.2.2434-3+deb11u3 |
| wget | 1.21-1+deb11u2 |
| zip | 3.0-12 |
| zlib1g | 1:1.2.11.dfsg-2+deb11u2 |
| zsh | 5.8-6+deb11u1 |

