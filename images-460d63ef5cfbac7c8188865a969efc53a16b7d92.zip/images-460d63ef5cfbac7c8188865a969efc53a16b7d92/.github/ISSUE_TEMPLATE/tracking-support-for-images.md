---
name: Tracking support for images
about: Helps keep track for adding support for new image variants
title: Support [Image Name] [variant/version] scheduled for [date]
labels: image-support

---

<!-- Add a reference link (if necessary) !--->
Depends on [add a reference link here]

- [ ] Open a PR 
- [ ] Create a release
- [ ] Update [templates](https://github.com/devcontainers/templates) (if necessary)
- [ ] Update https://github.com/devcontainers/images/issues/90
- [ ] Update [Microsoft Artifact Registry](https://mcr.microsoft.com/en-us/catalog?search=dev%20container) docs
